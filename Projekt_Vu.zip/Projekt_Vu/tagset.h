//class ClTagset
//{
//public:
//    ClTagset(int ntags,int natt, char **tags, char **atts);

//    void addTagset(int ntags, int natt, int slot,char **tags, char **atts);

//    int tagIstErlaubt(char *name);

//    int attIstErlaubt(char *name);

//    ClTagset *getChild(int slot) { return child[slot]; }

//private:
//    int anzahlTags;
//    char **tagNamen;

//    int anzahlAttribute;
//    char **attNamen;

//    ClTagset **child;
//} ;
